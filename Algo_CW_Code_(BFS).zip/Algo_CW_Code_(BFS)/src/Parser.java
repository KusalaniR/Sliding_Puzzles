import java.io.IOException;
import java.util.ArrayList;
import java.io.FileNotFoundException;
import java.util.Scanner;
import java.io.File;
import java.nio.charset.Charset;
import java.nio.file.Files;

public class Parser {
    protected Scanner lineScanner = null; //Scanner for reading lines from the input file
    private final ArrayList<String> lines = new ArrayList<>(); //ArrayList to store line read from the input file
    private boolean hasRead; //Flag to indicate whether the input file has been read
    protected int[] startPoint; //Array to so=tore the start points
    protected int[] endPoint; //Array to so=tore the start points
    protected int[][] maze; //2D array to represent the maze read from the input file
    private boolean hasLoaded;  //Flag to indicate whether the input file has been loaded
    private File inputFile; //File object representing the input file

    //it checks the file has been read or not. it will return the boolean value.
    public Boolean isFileRead() {
        return this.hasRead;
    }

    // here we are getting the value of start point.
    public int[] getStartPoint() {
        if (hasLoaded()) {
            return this.startPoint;
        }
        return null;
    }
    // here we are getting the value of end point.
    public int[] getEndPoint() {
        if (hasLoaded()) {
            return this.endPoint;
        }
        return null;
    }

    //here this method is used to return the whole maze which is the entire file including integer elements.
    public int[][] getPuzzle() {
        if (hasLoaded()) {
            return this.maze;
        }
        return null;
    }

    // here we are going to load the lines which we read. if we read the file, hasRead will be true. then go inside the if block.
    public void loadLines() throws IOException {
        if (this.hasRead) {
            //we are going to use the default charset which is ascii.
            lines.addAll(Files.readAllLines(inputFile.toPath(), Charset.defaultCharset()));
            this.hasLoaded = true;  // we are setting hasLoaded to true. (private boolean hasLoaded;)
        }
    }

    //Input the path, and it will throw FileNotFoundException. if the file is not in that location, it will throw an error.
    public void readFile(String path) throws FileNotFoundException {
        //there is an inbuilt class called File. from that we created an object called inputFile.
        File inputFile;
        inputFile = new File(path); //here I have given the path

        if (inputFile.length() == 0) {
            throw new FileNotFoundException("File " + path + " does not exist");
        }

        this.inputFile = inputFile;  //setting it to the inputFile which we created. (private File inputFile;)
        this.hasRead = true;  //(private boolean hasRead;) we have read the file now. so we are setting it to true.
    }

    public String getFileName() {
        if (hasLoaded) {
            return inputFile.getName();
        }
        return null;
    }

    public ArrayList<String> getLines() {
        // If hasRead is setting to true when we read the file, then go inside and return this.lines.
        // We have the whole file in this.lines array list which we saved in line 61.
        if (this.hasRead) {
            return this.lines;
        }
        return null;
    }


    public Boolean hasLoaded() {
        if (this.isFileRead()) {
            return this.hasLoaded;
        }
        return null;
    }

    //created a variable called lines which is a string array list.
    //setting those saved lines into a variable called lines here.
    public void loadValues(){
        ArrayList<String> lines = this.getLines();
        this.lineScanner = new Scanner(this.getLines().get(0));
        //created lineScanner above. It's a scanner object which we are getting it as an input. Here initiating it.
        //get(0) means it will get the first line of the particular file we loaded.

        int FloorSize = this.getLines().get(0).trim().length();
        //What trim will do is it will delete the leading and trailing white spaces in that line.
        this.maze = new int[FloorSize][lines.size()];  //maze is a 2D integer array that we created earlier.
                                                       // it will give number of columns and rows.
        int lineCount = 0; //We use this because we have 10 lines. we are going to read each and every line.

        //This for loop, it will traverse every line of that particular file. line by line.
        for (int i = 0; i < lines.size(); i++){  //traverse
            String line = lines.get(i);
            int[] floor = new int[FloorSize];
            this.lineScanner = new Scanner(line);
            int counter = 0; //Created a variable called counter. this variable is to limit it to the FloorSize.

            //this while loop, it will traverse in a particular line.
            while (lineScanner.hasNext()) {  //hasNext is an exception handling method.
                if (counter < FloorSize){   //The counter will be increased from 0 until it is less than the FloorSize.
                    String li = lineScanner.nextLine();  //created a string object called li.
                    li = li.replace("0", "1");  //Here what we are going to do is, if there is 0 in the line, we convert it to the 1.
                    li = li.replace(".", "0");  //Like wise here as well. The purpose is to convert the line into integers.

                    if(li.contains("S")){
                        this.startPoint = new int[]{lineCount, li.indexOf("S")};  //Line count is the row value. index of 'S' is column value.
                        li = li.replace("S", "0");
                    }
                    if(li.contains("F")){
                        this.endPoint = new int[]{lineCount, li.indexOf("F")};
                        li = li.replace("F", "0");
                    }
                    String[] string = li.split("");
     //converted all the elements of the line into integers. so we are going to save it as an integer array.
                    for (int j = 0; j < string.length; j++) {  //When this loop finishes, the whole first line will be in the floor[1] integer array.
                        floor[j] = Integer.parseInt(string[j]);  //integer array
                    }
                    lineCount++;
                }
                counter++;
            }
            lineScanner.close();
            lineScanner = null;
            maze[i] = floor;  //maze is used to save entire file. when finish the entire program, the maze variable will have the whole lines of that file.
        }
    }
}
