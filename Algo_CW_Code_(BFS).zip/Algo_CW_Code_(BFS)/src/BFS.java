import java.util.LinkedList;
import java.util.Queue;

public class BFS {
    //Inner class to represent coordinates and their properties
    static class Coordinate implements Comparable<Coordinate> {
        int row; //Row index of the coordinate
        int column; //Column index of the coordinate
        int distanceFromStart; //Distance from the starting point
        String path;  // Path taken to reach this coordinate
        Queue<int[]> queue = new LinkedList<>(); //integer queue

//this coordinate class is used to represent each and every element in the file. every element has coordinate values.
//we are using those coordinates and finding the path inside the shortest distance method.
        Coordinate(int row, int column, int distanceFromStart, String path, int[] l) {
            this.row = row;
            this.column = column;
            this.distanceFromStart = distanceFromStart;
            this.path = path  + " (" + (column + 1) + ", " + (row + 1) +")\n" ; //Path include coordinates
            this.queue.add(l); //Add coordinates to the queue
        }

        //Compare coordinates based on distance from start and path
        @Override
        public int compareTo(Coordinate coordinate) {
            //If both coordinates have the same distance from the start
            if (this.distanceFromStart == coordinate.distanceFromStart) {
                return this.path.compareTo(coordinate.path); //Compare their paths lexicographically
            }
            return this.distanceFromStart - coordinate.distanceFromStart;
        }

        //Convert coordinate to string format
        @Override
        public String toString() {
            return "Total distance: " + distanceFromStart + "\n. Start at: " + path ;
        }
    }

    //method to find the shortest path from ball to hole using BFS
    public String shortestDistance(int[][] maze, int[] ball, int[] hole) {
        int rows = maze.length, cols = maze[0].length; //Get the number of rows and columns in the maze
        boolean[][] visited = new boolean[rows][cols]; //Create a booolean array to track visited cells in the maze

        //Create a queue to perform BFS traversal
        Queue<Coordinate> pq = new LinkedList<>();
        //Add the string position to initial distance 0 and an empty path
        pq.offer(new Coordinate(ball[0], ball[1], 0, "", new int[]{}));


        //Define movable directions and corresponding coordinates
        String[] movableDirections = {"Move up to", "Move down to", "Move left to", "Move right to"};
        int[][] movableCoordinates = {{-1, 0}, {1, 0}, {0, -1}, {0, 1}};

        while (!pq.isEmpty()) { //Perform BFS traversal until the queue is empty
            Coordinate position = pq.poll(); //Retrieve the current position from the queue
            if (position.row == hole[0] && position.column == hole[1]) {
                //Build the path string if the hole is reached
                String[] steps = position.path.split("\n");
                //Build the path string if the hole is reached
                StringBuilder formattedPath = new StringBuilder();
                formattedPath.append("Total distance: ").append(position.distanceFromStart).append("\n");
                formattedPath.append("1. Start at: ").append("(").append(ball[1] + 1).append(",").append(ball[0] + 1).append(")\n");
                for (int i = 1; i < steps.length; i++) {
                    formattedPath.append(i + 1).append(". ").append(steps[i]).append("\n");
                }
                formattedPath.append(steps.length + 1).append(". Done!");
                return formattedPath.toString().trim(); // Remove trailing newline
            }

            //Explore movable directions from the current position
            for (int i = 0; i < movableCoordinates.length; i++) {
                //Initialize variable to current position and distance
                int row = position.row;
                int column = position.column;
                int distanceFromStart = position.distanceFromStart;
                String path = position.path;

                while (row >= 0 && row < rows && column >= 0 //Move until hitting a wall or reaching the hole
                        && column < cols && maze[row][column] == 0
                        && (row != hole[0] || column != hole[1])) {
                    row += movableCoordinates[i][0]; //Update position and distance
                    column += movableCoordinates[i][1];
                    distanceFromStart += 1;
                }

                //Move until hitting a wall or reaching the hole
                if (row != hole[0] || column != hole[1]) {
                    row -= movableCoordinates[i][0];
                    column -= movableCoordinates[i][1];
                    distanceFromStart -= 1;
                }

                //Add the new position to the queue if not visited before
                if (!visited[row][column]) {
                    visited[position.row][position.column] = true;
                    pq.offer(new Coordinate(row, column, distanceFromStart, path + movableDirections[i], new int[]{row, column}));
                }
            }
        }

        return "Path not available to reach the destination!";
    }

}
