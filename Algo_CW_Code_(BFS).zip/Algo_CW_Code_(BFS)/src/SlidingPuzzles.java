//Author Name: Kusalani Ransala Dandeniya
//IIT Student ID: 20221265
//Module; MODULE: 5SENG003C.2 Algorithms: Theory, Design and Implementation
//Coursework: Sliding Puzzles
//Date: 15/04/2024

import java.io.File;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Scanner;
import java.time.Duration;
import java.time.Instant;

public class SlidingPuzzles {
    private final static Scanner inputReader = new Scanner(System.in); //Scanner for user input
    private static Parser parsedInputFile; //Parser object for parsing input files
    private static boolean shouldSkipLoad; //Flag to determine whether to skip loading new input
    private static String inputFileName; //Variable to store the name of the input file

    public static void main(String[] args) {

        System.out.println("\n-------------- Sliding Puzzle --------------\n");

        while (true) {
            shouldSkipLoad = false;
            //Main menu
            System.out.println("Press 1 to Load new input");
            System.out.println("Press 0 to Quit the application");
            System.out.print("\nchoice: ");
            String loopChoice = inputReader.nextLine();

            switch (loopChoice) {
                case "0" -> System.exit(0); //Exit the application
                case "1" -> loadNewInput(); //Load new input
                default -> System.out.println("Invalid choice"); //Invalid input
            }
        }
    }

    //Method to calculate the distance using BFS
    private static void calculateDistance() {
        Instant startTime = null;
        Instant endTime = null;
        Duration timeElapsed = null;

        while (true) {
            //Display selected input file information
            System.out.println("\nSelected input file: " + inputFileName);
            System.out.println("Number of lines: " + parsedInputFile.getLines().size());

            //Get puzzle, start point, and end point from parsed input
            int[][] n = parsedInputFile.getPuzzle();
            int[] s = parsedInputFile.getStartPoint();
            int[] t = parsedInputFile.getEndPoint();

            // Create BFS solver object
            BFS solver = new BFS();

            //Option menu
            System.out.println("\n");
            System.out.println("Press 1 to print the path");
            System.out.println("Press 9 to restart the application.");
            System.out.print("\nChoice: ");

            String loopChoice = inputReader.nextLine();

            switch (loopChoice) {
                //Calculate and print the shortest path
                case "1" -> {
                    if (startTime == null) {
                        startTime = Instant.now(); //Start timing the distance calculation
                    }
                    System.out.println("\nFinding the distance...\n"); //Display the progress message
                    String path = solver.shortestDistance(n, s, t); //Calculate the shortest path using BFS
                    System.out.println(path);
                    int numberOfSteps = path.split("\n").length - 1; // Exclude the "Start at" line
                    System.out.println("\nPath found in the steps: " + numberOfSteps);
                    if (endTime == null) {
                        endTime = Instant.now();
                        timeElapsed = Duration.between(startTime, endTime); //Calculate the elapsed time
                    }
                    System.out.print("\nTime elapsed: ");
                    if (timeElapsed.toMillis() > 1000) { //Check if the elapsed time is more than 1 second
                        System.out.print(timeElapsed.getSeconds() + " seconds\n"); //If more than 1 second, display time in seconds
                        return;
                    }
                    System.out.print(timeElapsed.toMillis() + " milliseconds\n"); //If less than 1 second, display time in milliseconds
                }

                case "9" -> {
                    //Restart the application
                    System.out.println("\n");
                    inputFileName = null;
                    parsedInputFile = null;
                    shouldSkipLoad = true;
                    return;
                }
                default -> System.out.println("Invalid choice\n");
            }
        }
    }


    //Method to load new input file
    private static void loadNewInput() {
        while (true) {
            if (shouldSkipLoad)
                return;

            //Load input menu
            System.out.println("\nPress 1 to select an input file.");
            System.out.println("Press 2 to go back to the main menu.");

            System.out.print("\nChoice: ");
            String loopChoice = inputReader.nextLine();

            switch (loopChoice) {
                case "1" -> {
                    System.out.println("\nAvailable input files:");
                    try {
                        // Path to the input folder
                        File inputFolder = new File("src/input_files_go_here");

                        // Validate if the folder exists and is a directory
                        if (!inputFolder.exists() || !inputFolder.isDirectory()) {
                            System.out.println("Input folder does not exist or is not a directory.");
                            continue;
                        }

                        // List all files in the folder
                        File[] files = inputFolder.listFiles();

                        // Sort files based on custom order
                        Arrays.sort(files, Comparator.comparing(File::getName, (s1, s2) -> {
                            int i1 = getOrderIndex(s1);
                            int i2 = getOrderIndex(s2);
                            return Integer.compare(i1, i2);
                        }));

                        // Display only text file names
                        int count = 1;
                        for (File file : files) {
                            if (file.isFile() && file.getName().endsWith(".txt")) {
                                System.out.println(count + ". " + file.getName());
                                count++;
                            }
                        }

                        // If no text files found, inform the user
                        if (count == 1) {
                            System.out.println("No text files found in the input folder.");
                            continue;
                        }

                        // Prompt user for file choice
                        System.out.print("\nEnter the number corresponding to the file: ");
                        int fileChoice;
                        try {
                            fileChoice = Integer.parseInt(inputReader.nextLine());
                        } catch (NumberFormatException e) {
                            System.out.println("Invalid input. Please enter a number.");
                            continue;
                        }

                        // Validate user input
                        if (fileChoice < 1 || fileChoice >= count) {
                            System.out.println("Invalid file choice.");
                            continue;
                        }

                        // Load and process the selected file
                        String selectedFileName = "";
                        int currentCount = 1;
                        for (File file : files) {
                            if (file.isFile() && file.getName().endsWith(".txt")) {
                                if (currentCount == fileChoice) {
                                    selectedFileName = file.getName();
                                    break;
                                }
                                currentCount++;
                            }
                        }

                        inputFileName = selectedFileName;

                        Parser fileParser = new Parser(); //Create a new Parser object
                        fileParser.readFile("src/input_files_go_here/" + selectedFileName); //Read the selected input file
                        fileParser.loadLines(); //Load lines from the files
                        fileParser.loadValues();//Load values from the files
                        if (!fileParser.isFileRead()) {
                            throw new Exception("File not loaded");
                        }
                        parsedInputFile = fileParser; //Assign the parsed input file to the variable
                        shouldSkipLoad = true; //Set shouldSkipLoad to true to skip loading new input
                        calculateDistance(); //Calculate the distance for the loaded input
                    } catch (Exception e) { //Handle any exceptions
                        System.out.println("\nError reading input file, please try again.\n");
                        System.out.println(e.getMessage());
                    }
                }
                case "2" -> {
                    //Return to the main menu
                    return;
                }
                default -> System.out.println("Invalid choice. Please enter a valid input.");
            }
        }
    }

    // Method to get the order index for a file name
    private static int getOrderIndex(String fileName) {
        String[] order = {
                "maze10_", "maze15_", "maze20_", "maze25_", "maze30_",
                "puzzle_10", "puzzle_20", "puzzle_40", "puzzle_80",
                "puzzle_160", "puzzle_320", "puzzle_640", "puzzle_1280", "puzzle_2560",
                "test"
        };

        for (int i = 0; i < order.length; i++) {
            if (fileName.startsWith(order[i])) {
                return i;
            }
        }
        return order.length; // If not found, place it at the end
    }
}